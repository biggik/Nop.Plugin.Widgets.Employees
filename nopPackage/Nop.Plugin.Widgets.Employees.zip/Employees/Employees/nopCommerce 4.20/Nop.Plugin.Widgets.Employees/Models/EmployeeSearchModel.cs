﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Widgets.Employees.Models
{
    public class EmployeeSearchModel : BaseSearchModel
    {
    }
}
