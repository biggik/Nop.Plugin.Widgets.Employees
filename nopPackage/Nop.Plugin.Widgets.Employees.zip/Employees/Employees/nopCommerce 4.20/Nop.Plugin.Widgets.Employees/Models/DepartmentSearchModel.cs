﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Widgets.Employees.Models
{
    public class DepartmentSearchModel : BaseSearchModel
    {
    }
}
