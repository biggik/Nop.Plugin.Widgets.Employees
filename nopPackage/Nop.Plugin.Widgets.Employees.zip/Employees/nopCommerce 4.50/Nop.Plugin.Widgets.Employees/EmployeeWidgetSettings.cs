﻿using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.Employees
{
    public class EmployeeWidgetSettings : ISettings
    {
        public string WidgetZones { get; set; }
    }
}
