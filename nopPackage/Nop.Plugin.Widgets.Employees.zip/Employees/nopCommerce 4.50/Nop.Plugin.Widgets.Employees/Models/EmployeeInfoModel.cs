﻿namespace Nop.Plugin.Widgets.Employees.Models
{
    public class EmployeeInfoModel
    {
        public bool IsAdmin { get; set; }

        public EmployeeModel Employee { get; set; }
    }
}