﻿using Nop.Web.Framework;

namespace Nop.Plugin.Widgets.Employees.Constants;

internal static class Areas
{
    internal const string Admin = AreaNames.ADMIN;
}
